<?php

    return [
        'db' => [
            'host' => 'localhost',
            'name' => 'credit',
            'username' => 'root',
            'password' => '',
        ],
    ];

?>